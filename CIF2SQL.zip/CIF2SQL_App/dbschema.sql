CREATE TABLE IF NOT EXISTS protein (
   prot_id VARCHAR(6) PRIMARY KEY,
   title VARCHAR,
   depDate VARCHAR,
   classification VARCHAR,
   insDate VARCHAR,
   num_heterogen INTEGER,
   num_helix INTEGER,
   num_coord INTEGER,
   num_SeqRes INTEGER,
   num_Sheet INTEGER
);

CREATE TABLE IF NOT EXISTS keyword (
   protein_id VARCHAR(6),
   keyword VARCHAR,
   FOREIGN KEY (protein_id) REFERENCES protein(prot_id)
);

CREATE TABLE IF NOT EXISTS prot_source (
   protein_id VARCHAR(6),
   prot_source VARCHAR,
   FOREIGN KEY (protein_id) REFERENCES protein(prot_id)
);

CREATE TABLE IF NOT EXISTS prot_chain (
   chain_id VARCHAR PRIMARY KEY,
   prot_fk VARCHAR(6) NOT NULL,
   chain_name VARCHAR,
   chain_length INTEGER,
   FOREIGN KEY (prot_fk) REFERENCES protein(prot_id)
);

CREATE TABLE IF NOT EXISTS standard_amino (
   name3 VARCHAR(3) PRIMARY KEY,
   amino_name VARCHAR,
   amino_symbol VARCHAR,
   genetic_coding VARCHAR,
   amino_hydropathy DOUBLE PRECISION,
   amino_mass DOUBLE PRECISION,
   amino_abundance DOUBLE PRECISION,
   amino_charge VARCHAR,
   amino_polarity VARCHAR,
   amino_class VARCHAR
);

CREATE TABLE IF NOT EXISTS residue (
   residue_id VARCHAR PRIMARY KEY,
   residue_seqNum INTEGER,
   standardAmino_fk VARCHAR(3) NOT NULL,
   chain_fk VARCHAR,
   FOREIGN KEY (chain_fk) REFERENCES prot_chain(chain_id),
   FOREIGN KEY (standardAmino_fk) REFERENCES standard_amino(name3)
);

CREATE TABLE IF NOT EXISTS atom (
   atom_id VARCHAR PRIMARY KEY,
   model INTEGER,
   atom_name VARCHAR,
   altLoc CHAR,
   X_coord DOUBLE PRECISION,
   Y_coord DOUBLE PRECISION,
   Z_coord DOUBLE PRECISION,
   tempFactor DOUBLE PRECISION,
   occupancy DOUBLE PRECISION,
   charge DOUBLE PRECISION,
   serial_number INTEGER,
   residue_FK VARCHAR,
   FOREIGN KEY (residue_FK) REFERENCES residue(residue_id)
);

CREATE TABLE IF NOT EXISTS ligand (
   lig_id VARCHAR PRIMARY KEY,
   lig_name VARCHAR,
   lig_formul VARCHAR,
   lig_seqNum INTEGER,
   lig_name3 VARCHAR,
   lig_synonims VARCHAR,
   chain_FK VARCHAR,
   FOREIGN KEY (chain_FK) REFERENCES prot_chain(chain_id)
);

CREATE TABLE IF NOT EXISTS hetAtom (
   hetAtom_id VARCHAR PRIMARY KEY,
   model INTEGER,
   hetAtom_name VARCHAR,
   altLoc CHAR,
   X_coord DOUBLE PRECISION,
   Y_coord DOUBLE PRECISION,
   Z_coord DOUBLE PRECISION,
   tempFactor DOUBLE PRECISION,
   occupancy DOUBLE PRECISION,
   charge DOUBLE PRECISION,
   serial_number INTEGER,
   ligand_FK VARCHAR,
   FOREIGN KEY (ligand_FK) REFERENCES ligand(lig_id)
);

CREATE TABLE IF NOT EXISTS helix (
   helix_id VARCHAR PRIMARY KEY,
   prot_fk VARCHAR(6),
   helix_comment VARCHAR,
   helix_class VARCHAR,
   helix_length INTEGER,
   initRes_fk VARCHAR,
   endRes_fk VARCHAR,
   seqResChain VARCHAR,
   FOREIGN KEY (prot_fk) REFERENCES protein(prot_id)
);

CREATE TABLE IF NOT EXISTS helix_subchain (
   helix_id VARCHAR,
   res_id VARCHAR,
   FOREIGN KEY (helix_id) REFERENCES helix(helix_id),
   FOREIGN KEY (res_id) REFERENCES residue(residue_id)
);

CREATE TABLE IF NOT EXISTS ssBond (
   ssBond_id VARCHAR PRIMARY KEY,
   sym1 VARCHAR,
   sym2 VARCHAR,
   ssBond_length VARCHAR,
   res1_fk VARCHAR,
   res2_fk VARCHAR
);

CREATE TABLE IF NOT EXISTS sheet (
   sheet_id VARCHAR PRIMARY KEY,
   num_Strands INTEGER,
   prot_fk VARCHAR(6),
   FOREIGN KEY (prot_fk) REFERENCES protein(prot_id)
);

CREATE TABLE IF NOT EXISTS strand (
   strand_id VARCHAR PRIMARY KEY,
   sheet_FK VARCHAR,
   initRes_FK VARCHAR,
   endRes_FK VARCHAR,
   sense VARCHAR,
   currRes_FK VARCHAR,
   prevRes_FK VARCHAR,
   currAtom VARCHAR,
   prevAtom VARCHAR,
   seqResChain VARCHAR,
   FOREIGN KEY (sheet_FK) REFERENCES sheet(sheet_id)
);

CREATE TABLE IF NOT EXISTS strand_subchain (
   strand_id VARCHAR,
   res_id VARCHAR,
   FOREIGN KEY (strand_id) REFERENCES strand(strand_id),
   FOREIGN KEY (res_id) REFERENCES residue(residue_id)
);

INSERT INTO standard_amino
(name3, amino_name, amino_symbol, genetic_coding, amino_hydropathy, amino_mass, amino_abundance, amino_charge, amino_polarity, amino_class)
VALUES
('ALA','Alanine','A','GCN','1.8','89.094','8.76','Neutral','Nonpolar','Aliphatic'),
('ARG','Arginine','R','MGR, CGY','-4.5','174.203','5.78','Positive','Basic Polar','Fixed'),
('ASN','Asparagine','N','AAY','-3.5','132.119','3.93','Neutral','Polar','Amide'),
('ASP','Aspartate','D','GAY','-3.5','133.104','5.49','Negative','Bronsted Base','Anion'),
('CYS','Cysteine','C','UGY','2.5','121.154','1.38','Neutral','Bronsted Acid','Thiol'),
('GLN','Glutamine','Q','CAR','-3.5','146.146','3.9','Neutral','Polar','Amide'),
('GLU','Glutamate','E','GAR','-3.5','147.131','6.32','Negative','Bronsted Acid','Anion'),
('GLY','Glycine','G','AUH','4.5','75.067','5.49','Neutral','Nonpolar','Alipathic'),
('HIS','Histidine','H','CAY','-3.2','155.156','2.25','Positive 10%, Neutral 90%','Bronsted acid and base','Aromatic Cation'),
('ILE','Isoleucine','I','AUH','4.5','131.175','5.49','Neutral','Nonpolar','Alipathic'),
('LEU','Leucine','L','YUR CUY','3.8','131.175','9.68','Neutral','Nonpolar','Alipathic'),
('LYS','Lysine','K','AAR','-3.9','146.189','5.19','Positive','Bronsted Acid','Cation'),
('MET','Methionine','M','AUG','1.9','149.208','2.32','Neutral','Nonpolar','Thioether'),
('PHE','Phenylalanine','F','UUY','2.8','165.192','3.87','Neutral','Nonpolar','Aromatic'),
('PRO','Proline','P','CCN','-1.6','115.132','5.02','Neutral','Nonpolar','Cyclic'),
('SER','Serine','S','UCN AGY','-0.8','105.093','7.14','Neutral','Polar','Hydroxylic'),
('THR','Tyrosine','Y','ACN','-1.3','181.191','2.91','Neutral','Bronsted Acid','Aromatic'),
('TRP','Tryptophan','W','UGG','-0.9','204.228','1.25','Neutral','Nonpolar','Aromatic'),
('TYR','Tyrosine','Y','UAY','-1.3','181.191','2.91','Neutral','Bronsted Acid','Aromatic'),
('VAL','Valine','V','GUN','4.2','117.148','6.73','Neutral','Nonpolar','Alipathic');

