CREATE TABLE IF NOT EXISTS protein (
   protein_id VARCHAR(6) PRIMARY KEY,
   title VARCHAR,
   deposit_date VARCHAR,
   classification VARCHAR,
   insertion_date VARCHAR,
   num_heterogen INTEGER,
   num_helix INTEGER,
   num_atoms INTEGER,
   num_seq_residues INTEGER,
   num_sheets INTEGER
);

CREATE TABLE IF NOT EXISTS keyword (
   protein_id VARCHAR(6),
   keyword_value VARCHAR,
   FOREIGN KEY (protein_id) REFERENCES protein(protein_id)
);

CREATE TABLE IF NOT EXISTS source (
   protein_id VARCHAR(6),
   source_organism VARCHAR,
   FOREIGN KEY (protein_id) REFERENCES protein(protein_id)
);

CREATE TABLE IF NOT EXISTS chain ( 
   chain_id VARCHAR PRIMARY KEY,
   protein_id VARCHAR(6) NOT NULL,
   chain_name VARCHAR,
   chain_length INTEGER,
   FOREIGN KEY (protein_id) REFERENCES protein(protein_id)
);

CREATE TABLE IF NOT EXISTS amino_acid (
   amino_id VARCHAR(3) PRIMARY KEY,
   one_letter_code VARCHAR,
   amino_name VARCHAR,
   genetic_coding VARCHAR,
   hydropathy DOUBLE PRECISION,
   mass DOUBLE PRECISION,
   abundance DOUBLE PRECISION,
   amino_charge VARCHAR,
   polarity VARCHAR,
   amino_class VARCHAR
);

CREATE TABLE IF NOT EXISTS residue (
   residue_id VARCHAR PRIMARY KEY,
   sequence_number INTEGER,
   amino_id VARCHAR(3) NOT NULL,
   chain_id VARCHAR,
   FOREIGN KEY (amino_id) REFERENCES amino_acid(amino_id),
   FOREIGN KEY (chain_id) REFERENCES chain(chain_id)
);

CREATE TABLE IF NOT EXISTS residue_atom (
   ratom_id VARCHAR PRIMARY KEY,
   ratom_model INTEGER,
   ratom_name VARCHAR,
   ratom_alt_location CHAR,
   ratom_x_coord DOUBLE PRECISION,
   ratom_y_coord DOUBLE PRECISION,
   ratom_z_coord DOUBLE PRECISION,
   ratom_temp_factor DOUBLE PRECISION,
   ratom_occupancy DOUBLE PRECISION,
   ratom_charge DOUBLE PRECISION,
   ratom_serial_number INTEGER,
   residue_id VARCHAR,
   FOREIGN KEY (residue_id) REFERENCES residue(residue_id)
);

CREATE TABLE IF NOT EXISTS heterogen (
   heterogen_id VARCHAR PRIMARY KEY,
   heterogen_name VARCHAR,
   formula VARCHAR,
   heterogen_sequence_number INTEGER,
   heterogen_three_letter_code VARCHAR,
   synonims VARCHAR,
   chain_id VARCHAR,
   FOREIGN KEY (chain_id) REFERENCES chain(chain_id)
);

CREATE TABLE IF NOT EXISTS heterogen_atom (
   hatom_id VARCHAR PRIMARY KEY,
   hatom_model INTEGER,
   hatom_name VARCHAR,
   hatom_alt_location CHAR,
   hatom_x_coord DOUBLE PRECISION,
   hatom_y_coord DOUBLE PRECISION,
   hatom_z_coord DOUBLE PRECISION,
   hatom_temp_factor DOUBLE PRECISION,
   hatom_occupancy DOUBLE PRECISION,
   hatom_charge DOUBLE PRECISION,
   hatom_serial_number INTEGER,
   heterogen_id VARCHAR,
   FOREIGN KEY (heterogen_id) REFERENCES heterogen(heterogen_id)
);

CREATE TABLE IF NOT EXISTS helix (
   helix_id VARCHAR PRIMARY KEY,
   protein_id VARCHAR(6),
   helix_comment VARCHAR,
   helix_class VARCHAR,
   helix_length INTEGER,
   initial_residue_id VARCHAR,
   end_residue_id VARCHAR,
   sequence_residue_chain VARCHAR,
   FOREIGN KEY (protein_id) REFERENCES protein(protein_id)
);

CREATE TABLE IF NOT EXISTS helix_residue (
   helix_id VARCHAR,
   residue_id VARCHAR,
   FOREIGN KEY (helix_id) REFERENCES helix(helix_id),
   FOREIGN KEY (residue_id) REFERENCES residue(residue_id)
);

CREATE TABLE IF NOT EXISTS disulfide_bond (
   bond_id VARCHAR PRIMARY KEY,
   symmetry_operator_1 VARCHAR,
   symmetry_operator_2 VARCHAR,
   bond_length VARCHAR,
   residue1_id VARCHAR,
   residue2_id VARCHAR
);

CREATE TABLE IF NOT EXISTS sheet (
   sheet_id VARCHAR PRIMARY KEY,
   strands_number INTEGER,
   protein_id VARCHAR(6),
   FOREIGN KEY (protein_id) REFERENCES protein(protein_id)
);

CREATE TABLE IF NOT EXISTS strand (
   strand_id VARCHAR PRIMARY KEY,
   sheet_id VARCHAR,
   initial_residue_id VARCHAR,
   end_residue_id VARCHAR,
   sense VARCHAR,
   current_residue_id VARCHAR,
   previous_residue_id VARCHAR,
   current_atom VARCHAR,
   previous_atom VARCHAR,
   sequence_residue_chain VARCHAR,
   FOREIGN KEY (sheet_id) REFERENCES sheet(sheet_id)
);

CREATE TABLE IF NOT EXISTS strand_residue (
   strand_id VARCHAR,
   residue_id VARCHAR,
   FOREIGN KEY (strand_id) REFERENCES strand(strand_id),
   FOREIGN KEY (residue_id) REFERENCES residue(residue_id)
);



INSERT INTO amino_acid
(amino_id, amino_name, one_letter_code, genetic_coding, hydropathy, mass, abundance, amino_charge, polarity, amino_class)
VALUES
('ALA','Alanine','A','GCN','1.8','89.094','8.76','Neutral','Nonpolar','Aliphatic'),
('ARG','Arginine','R','MGR, CGY','-4.5','174.203','5.78','Positive','Basic Polar','Fixed'),
('ASN','Asparagine','N','AAY','-3.5','132.119','3.93','Neutral','Polar','Amide'),
('ASP','Aspartate','D','GAY','-3.5','133.104','5.49','Negative','Bronsted Base','Anion'),
('CYS','Cysteine','C','UGY','2.5','121.154','1.38','Neutral','Bronsted Acid','Thiol'),
('GLN','Glutamine','Q','CAR','-3.5','146.146','3.9','Neutral','Polar','Amide'),
('GLU','Glutamate','E','GAR','-3.5','147.131','6.32','Negative','Bronsted Acid','Anion'),
('GLY','Glycine','G','AUH','4.5','75.067','5.49','Neutral','Nonpolar','Alipathic'),
('HIS','Histidine','H','CAY','-3.2','155.156','2.25','Positive 10%, Neutral 90%','Bronsted acid and base','Aromatic Cation'),
('ILE','Isoleucine','I','AUH','4.5','131.175','5.49','Neutral','Nonpolar','Alipathic'),
('LEU','Leucine','L','YUR CUY','3.8','131.175','9.68','Neutral','Nonpolar','Alipathic'),
('LYS','Lysine','K','AAR','-3.9','146.189','5.19','Positive','Bronsted Acid','Cation'),
('MET','Methionine','M','AUG','1.9','149.208','2.32','Neutral','Nonpolar','Thioether'),
('PHE','Phenylalanine','F','UUY','2.8','165.192','3.87','Neutral','Nonpolar','Aromatic'),
('PRO','Proline','P','CCN','-1.6','115.132','5.02','Neutral','Nonpolar','Cyclic'),
('SER','Serine','S','UCN AGY','-0.8','105.093','7.14','Neutral','Polar','Hydroxylic'),
('THR','Tyrosine','Y','ACN','-1.3','181.191','2.91','Neutral','Bronsted Acid','Aromatic'),
('TRP','Tryptophan','W','UGG','-0.9','204.228','1.25','Neutral','Nonpolar','Aromatic'),
('TYR','Tyrosine','Y','UAY','-1.3','181.191','2.91','Neutral','Bronsted Acid','Aromatic'),
('VAL','Valine','V','GUN','4.2','117.148','6.73','Neutral','Nonpolar','Alipathic');

