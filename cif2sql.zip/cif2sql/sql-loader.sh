#!/bin/bash

# CONFIG
PGPATH="/usr/bin"
DB_HOST="DB ADDRESS"
DB_PORT="DB PORT"
DB_NAME="DB NAME"
DB_USER="DB USERNAME"
DB_PASS="PASSWORD"
LOG_FOLDER="PATH WHERE SQL-LOADER-LOGS ARE LOCATED"
SQL_FOLDER="PATH WHERE THE SQL FILES ARE LOCATED"

mkdir -p "$LOG_FOLDER"

export PGPASSWORD="$DB_PASS"

echo
echo "Reading SQL files..."

for F in "$SQL_FOLDER"/*.sql; do
    [ -e "$F" ] || { echo "No SQL files found."; break; }

    echo
    echo "Reading: $(basename "$F")"

    TEMP_LOG="$(mktemp)"

    "$PGPATH/psql" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -q -v ON_ERROR_STOP=1 -f "$F" > "$TEMP_LOG" 2>&1

    if [[ $? -ne 0 ]]; then
        echo "Error reading $(basename "$F")"
        echo "Saving log as $LOG_FOLDER/$(basename "${F%.sql}.log")"
        mv "$TEMP_LOG" "$LOG_FOLDER/$(basename "${F%.sql}.log")"
        HAS_ERRORS=1
    else
        echo "$(basename "$F") successfully added to the database."
        rm -f "$TEMP_LOG"
    fi

done

echo
if [[ -n "$HAS_ERRORS" ]]; then
    echo "Check $LOG_FOLDER."
else
    echo "All files were added to the database."
fi

unset PGPASSWORD
echo